# 🫶 Code de Conduite — A KI PRI SA YÉ

---

## 👋 Notre engagement

Pour que tout le monde se sente bienvenu :
- Respect mutuel
- Bienveillance
- Aucune discrimination ni harcèlement

---

## 🚫 Ce qui est interdit

- Insultes ou attaques personnelles
- Discours haineux ou discriminatoire
- Spam ou contenu hors sujet

---

## ✅ Comment signaler

Si tu constates un comportement inapproprié :
- Ouvre une Issue privée ou
- Contacte directement [teetee971](https://github.com/teetee971)

---

## 🤝 Engagement

En participant, tu acceptes de suivre ce Code de Conduite.

**Lé lavi chè, nou ansam !**
