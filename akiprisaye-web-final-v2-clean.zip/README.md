# A KI PRI SA YÉ – Version Web Finale

Cette archive contient la version web optimisée de l’application **A KI PRI SA YÉ**, prête pour un déploiement rapide sur **GitHub Pages** ou **Firebase Hosting**.

## Structure du projet
```
/
├── index.html
├── style.css
├── manifest.json
├── robots.txt
├── sitemap.xml
├── firebase.json
├── .firebaserc
└── assets/
    └── logo.png
```

## Déploiement

### GitHub Pages
1. Créez un nouveau dépôt sur GitHub.
2. Ajoutez les fichiers de cette archive (commit & push).
3. Dans *Settings ▸ Pages*, sélectionnez la branche **main** et le dossier racine.
4. Validez : votre site sera disponible sous `https://<votre‑user>.github.io/<repo>/`.

### Firebase Hosting
```bash
npm install -g firebase-tools   # si nécessaire
firebase login
firebase init hosting           # choisissez "Configure files for Firebase Hosting"
firebase deploy                 # mise en ligne ✨
```

## Licence
MIT
