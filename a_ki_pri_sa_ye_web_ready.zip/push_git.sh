#!/bin/bash
git init
git remote add origin https://github.com/<TON_UTILISATEUR>/<TON_DEPOT>.git
git add .
git commit -m "🎉 Initial commit du projet web A KI PRI SA YÉ"
git branch -M main
git push -u origin main
