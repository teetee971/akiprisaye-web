# A KI PRI SA YÉ – Module Chat IA Local

Instructions :

1. `npm install`
2. `npm run dev` pour tester localement
3. Connectez Firebase avec vos clés dans `firebase_config.js`
4. Déployez sur Vercel ou Firebase Hosting
